package pacotes_28309.control;

public class Main {
	public static void main(String[] args) {
		
		// Inicia a aplicação.
		new AppControl();
	}
}
